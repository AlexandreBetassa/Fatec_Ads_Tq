document.getElementById("btnCalcular").addEventListener("click", function () {
    var valor = document.getElementById("valor").value;
    var qtdParcelas = document.getElementById("qtdParcelas").value;
    valor = parseFloat(valor);
    qtdParcelas = parseFloat(qtdParcelas);
    var montante;

    if (qtdParcelas <= 12) {
        montante = valor * Math.pow(1 + (1 / 100), qtdParcelas);
        imprimir(montante, qtdParcelas);
    } else if (qtdParcelas > 12 && qtdParcelas <= 24) {
        montante = valor * Math.pow(1 + (1.5 / 100), qtdParcelas);
        imprimir(montante, qtdParcelas);
    } else if (qtdParcelas > 24 && qtdParcelas <= 36) {
        montante = valor * Math.pow(1 + (1.5 / 100), qtdParcelas);
        imprimir(montante, qtdParcelas);
    } else {
        montante = valor * Math.pow(1 + (1.5 / 100), qtdParcelas);
        imprimir(montante, qtdParcelas);
    }
});

function imprimir(montante, qtdParcelas) {
    let valorParc = (montante/qtdParcelas);
    let valor = valorParc;
    let html = "";
    for(let i = 0; i < qtdParcelas; i++){
        html += "<tr><td>"+(i+1)+"</td><td>R$ "+valorParc.toFixed(2)+"</td><td>R$ "+valor.toFixed(2)+"</td></tr>"
        valor += parseFloat(valorParc);
    }
    document.getElementById("tbody").innerHTML = html;
}